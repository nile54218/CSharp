﻿using GSTLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class GSTConsumer
    {
        static void Main(string[] args)
        {
            double gstamt;
            Console.WriteLine("enter original amount");
            double originalamt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter gst rate");
            double gstrate = Convert.ToDouble(Console.ReadLine());
            GSTDemo gsttest = new GSTDemo(originalamt, gstrate);

            Console.WriteLine($"total amount : {gsttest.calculate(out gstamt)}");
            Console.WriteLine($"Gst amount : {gstamt}");
            Console.ReadLine();
        }
    }
}
