﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{

    public static class IntExtension
    {
        public static int IsPositive(this int i, int value)
        {
            if (i > 0)
            {
                return i + value;
            }
            else
            {
                return -1;
            }
        }
    }

    class TestExtensionMethod
    {
        static void Main(string[] args)
        {

            Console.WriteLine("enter two numbers");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());

            int result = num1.IsPositive(num2);
            if (result > 0)
            {
                Console.WriteLine($"sum of {num1} and {num2} = {result}");
            }
            else
            {
                Console.WriteLine($"{num1} is negative");
            }
            //Console.WriteLine(result ? "greater" : "smaller");
            Console.ReadLine();
        }
    }
}