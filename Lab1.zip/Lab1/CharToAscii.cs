﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class CharToAscii
    {
        static void Main()
        {
            //convert char into ascii and vice versa


            Console.WriteLine("enter character");
            char ch = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("enter number");
            int num = Convert.ToInt32(Console.ReadLine());
            int ascii = ch;
            char ch2 = (char)num;


            Console.WriteLine("character ch  ascii value= {0}", ascii);
            Console.WriteLine("character ch2 is {0}", ch2);
            Console.ReadLine();
        }



    }
}
