﻿using System;


namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
   
        }

    }
}
