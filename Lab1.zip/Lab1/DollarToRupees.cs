﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class DollarToRupees
    {
        static void Main()
        {
            // converting dollar to rupees and vice versa

            DollarToRupees obj = new DollarToRupees();
            Console.WriteLine("enter dollers");
            double dollar = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("dollar to rupees {0} = {1}", dollar, obj.torupees(dollar));

            Console.WriteLine("enter rupees");
            int rupees = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("rupees to dollar {0} = {1}", rupees, obj.todollar(rupees));
            Console.ReadLine();
        }


        public int torupees(double dollar)
        {
            return (int)(dollar * 70);
        }

        public double todollar(int rupees)
        {
            return (double)(rupees / 70);
        }
    }
}
