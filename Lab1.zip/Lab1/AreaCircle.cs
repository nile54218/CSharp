﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class AreaCircle
    {
        static void Main()
        {
            // calculate area of circle using constant

            const double PI = 3.14;
            Console.WriteLine("enter radius");
            double r = Convert.ToInt32(Console.ReadLine());
            AreaCircle obj = new AreaCircle();
            Console.WriteLine("area of circle is {0}", obj.area(r, PI));
            Console.ReadLine();
        }


        public double area(double r, double pi)
        {
            return r * r * pi;
        }
    }
}
