﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Numbers
    {
        static void Main()
        {
            //reverse numbers from 50 to 1

            Console.WriteLine("numbers in reversed from 50 to 1");
            for (int i = 50; i > 0; i--)
            {
                Console.WriteLine(i);

            }



            //odd numbers from 1 to 50 using do while

            Console.WriteLine("odd numbers from 1 to 50");
            int j = 1;
            do
            {
                if (j % 2 != 0)
                {
                    Console.WriteLine(j);
                }
                j++;
            } while (j < 51);



            // odd numbers between 1 to 50 from given array

            int[] nums = new int[5];

            Console.WriteLine("enter 5 array elements..");

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("enter {0} element");
                nums[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("odd numbers between 1 to 50 from given array");
            foreach (var num in nums)
            {
                if (num > 1 && num < 50 && num % 2 != 0)
                {
                    Console.WriteLine(num);
                }
            }


            //identifying even numbers from given array

            Console.WriteLine("even numbers from given array");
            foreach (var num in nums)
            {
                if (num % 2 == 0)
                {
                    Console.WriteLine(num);
                }
            }


            //printing a table of number


            Console.WriteLine("enter a number");
            int numb = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("printing a table of number");
            for (int i = 1; i < 11; i++)
            {
                Console.WriteLine(i * numb);
            }

            Console.ReadLine();
        }
    }
}
