﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Grade
    {
        static void Main()
        {
            // grade as per percentage
            Console.WriteLine("enter percentage");
            double percent = Convert.ToDouble(Console.ReadLine());

            if (percent >= 85)
            {
                Console.WriteLine("O grade");
            }
            else if (percent >= 75 && percent < 85)
            {
                Console.WriteLine("A grade");
            }
            else if (percent > 60 && percent < 75)
            {
                Console.WriteLine("B grade");
            }
            else
            {
                Console.WriteLine("pass class");
            }

            Console.ReadLine();
        }
    }
}
