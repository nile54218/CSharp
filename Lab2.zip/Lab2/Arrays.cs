﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Arrays
    {
        static void Main()
        {

            //sum of array
            Console.WriteLine("programme to find sum of array..");
            int[] nums2 = new int[5];
            Console.WriteLine("enter 5 array elements..");
            int sum = 0;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("enter {0} element", i + 1);
                nums2[i] = Convert.ToInt32(Console.ReadLine());
                sum += nums2[i];
            }

            Console.WriteLine("sum of array is {0}", sum);




            //sum of diagonal elements of array

            Console.WriteLine("programme to find sum of diagonal elements of array..");
            int[,] nums3 = new int[3, 3];
            Console.WriteLine("enter 9 array elements..");

            for (int i = 0; i < 3; i++)
            {
                for (int m = 0; m < 3; m++)
                {
                    nums3[i, m] = Convert.ToInt32(Console.ReadLine());
                }
            }

            int diagonal = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int l = 0; l < 3; l++)
                {
                    if (i == l)
                    {
                        diagonal += nums3[i, l];
                    }
                }
            }

            Console.WriteLine("sum of diagonal elements is {0}", diagonal);


            Console.WriteLine("programme to find element in jagged array..");
            // finding target in jagged array
            int[][] nums4 = new int[2][];
            nums4[0] = new int[3] { 10, 20, 30 };
            nums4[1] = new int[2] { 40, 50 };

            Console.WriteLine("enter target element");
            int target = Convert.ToInt32(Console.ReadLine());
            int flag = 0;

            for (int i = 0; i < 2; i++)
            {
                foreach (var item in nums4[i])
                {
                    if (item == target)
                    {
                        Console.WriteLine("target found!");
                        flag = 1;
                        break;
                    }
                }
                if (flag == 1)
                {
                    break;
                }
            }

            if (flag == 0)
            {
                Console.WriteLine("target not found!");
            }




            //printing sum of rows
            Console.WriteLine("programme to find sum of rows of array..");
            int[,] nums5 = { { 10, 20, 30 }, { 40, 50, 60 }, { 70, 80, 90 } };
            int[] rowsum = new int[3];
            int rsum;

            for (int i = 0; i < 3; i++)
            {
                rsum = 0;
                for (int k = 0; k < 3; k++)
                {
                    rsum += nums5[i, k];

                }

                rowsum[i] = rsum;
            }

            Console.WriteLine("row wise sum..");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("row {0} = {1}", i + 1, rowsum[i]);
            }



            //printing ascii from a to i

            Console.WriteLine("programme to find ascii values of a to i ..");
            int charascii;
            for (char ch = 'a'; ch <= 'i'; ch++)
            {
                charascii = ch;
                Console.Write("{0}\t", charascii);
                if (charascii % 3 == 0)
                    Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
