﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class MajorMinor
    {
        static void Main()
        {
            // person is major / minor
            Console.WriteLine("enter age of the person");
            int age = Convert.ToInt32(Console.ReadLine());
            if (age < 18)
            {
                Console.WriteLine("you are minor");
            }
            else
            {
                Console.WriteLine("you are major");
            }


            // person is major / minor using ternary operator


            string res = age > 18 ? "person is major" : "person is minor";
            Console.WriteLine(res);

            Console.ReadLine();
        }
    }
}
