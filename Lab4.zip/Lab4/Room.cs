﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class Room
    {
        private int number,floor,capacity;
        private string type;
        private double price;
        private DateTime bookedtime;


        public int Number
        {
            get
            {
                return number;
            }

            set
            {
                number = value;
            }

        }

        public int Floor
        {
            get
            {
                return floor;
            }

            set
            {
                floor = value;
            }

        }

        public int Capacity
        {
            get
            {
                return capacity;
            }

            set
            {
                capacity = value;
            }

        }

        public string Type
        {
            get
            {
                return type;
            }

            set
            {
                type = value;
            }
        }


        public DateTime BookedTime
        {
            get
            {
                return bookedtime;
            }

            set
            {
                bookedtime = value;
            }
        }

        public double Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }


        public Room()
        {
            Console.WriteLine("default constructor of Room");
        }

        public Room(int number,int floor,string type,int capacity,DateTime bookedtime,double price)
        {
            this.number = number;
            this.floor = floor;
            this.type = type;
            this.capacity = capacity;
            this.bookedtime = bookedtime;
            this.price = price;
        }

        public override string ToString()
        {
            return $"Number: {this.number} \n " +
                $"Floor: {this.floor} \n" +
                $"Type: {this.type} \n" +
                $"Capacity: {this.capacity} \n" +
                $"BookedTime: {this.bookedtime} \n" +
                $"Price: {this.price}";
        }


        static void Main()
        {
            Console.WriteLine("enter room number");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter floor");
            int floor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter type");
            string type = Console.ReadLine();
            
            Console.WriteLine("enter capacity");
            int capacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter booked time");
            DateTime bookedtime = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("enter price");
            double price = Convert.ToDouble(Console.ReadLine());

            Room room = new Room(number, floor, type, capacity, bookedtime,price);
            Console.WriteLine($"user details are \n {room}");
            Console.ReadLine();
        }
    }


    
}
