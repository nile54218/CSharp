﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class User
    {
        private long id;
        private string name;
        private string emailId;
        private string dateOfBirth;


        public long Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Name
        {
            get
            {
                return name;

            }

            set
            {
                name = value;
            }
        }

        public string Email
        {
            get
            {
                return emailId;
            }

            set
            {
                emailId = value;
            }
        }

        public string Birthday
        {
            get
            {
                return dateOfBirth;
            }

            set
            {
                dateOfBirth = value;
            }
        }


        public User()
        {

        }

        public User(long id,string name,string emailId,string dateOfBirth)
        {
            this.id = id;
            this.name = name;
            this.emailId = emailId;
            this.dateOfBirth = dateOfBirth;
        }


        public override string ToString()
        {
            return $"ID: {this.id} \n " +
            $"NAME: {this.name} \n" +
            $"EMAIL ID: {this.emailId} \n" +
            $"DATE OF BIRTH: {this.dateOfBirth}";
                
        }

        public static bool Validate(List<User> users,string mail)
        {

            foreach (var user in users)
            {
                if (user.emailId == mail)
                {
                    return false;
                }
            }
            return true;

        }

        static void Main()
        {


            List<User> users = new List<User>();
            int choice;

            do
            {
                Console.WriteLine("enter user ID");
                long id = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("enter user name");
                string name = Console.ReadLine();
                Console.WriteLine("enter user email ID");
                string emailId = Console.ReadLine();
                bool result = Validate(users, emailId);

                while (!result)
                {

                    Console.WriteLine("email ID already taken....enter different email ID");
                    emailId = Console.ReadLine();
                    result = Validate(users, emailId);
                }
                Console.WriteLine("enter date of birth");
                string dateOfBirth = Console.ReadLine();

                User user = new User(id, name, emailId, dateOfBirth);
                users.Add(user);
                Console.WriteLine($"user details are \n {user}");
                

                Console.WriteLine("want to register again ?");
                Console.WriteLine("1 => register \t 2 => exit");
                choice = Convert.ToInt32(Console.ReadLine());
            } while (choice != 2);
        }
    }
}
