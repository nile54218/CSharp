﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    abstract class Computer
    {

        public abstract void Bootup();
        public abstract void Shutdown();
    }


    class SuperComputer : Computer
    {
        public override void Bootup()
        {
            Console.WriteLine("supercomputer is booting up");
        }

        public override void Shutdown()
        {
            Console.WriteLine("supercomputer is shutting down");
        }
    }

    class MainframeComputer : Computer
    {
        public override void Bootup()
        {
            Console.WriteLine("Mainframe computer is booting up");
        }

        public override void Shutdown()
        {
            Console.WriteLine("Mainframe computer is shutting down");
        }
    }

    class MicroComputer : Computer
    {
        public override void Bootup()
        {
            Console.WriteLine("Micro computer is booting up");
        }

        public override void Shutdown()
        {
            Console.WriteLine("Micro computer is shutting down");
        }
    }


    public sealed class Pen
    {
        void StartWriting()
        {
            Console.WriteLine("started writing..");
        }

        void StopWriting()
        {
            Console.WriteLine("Stopped Writing");
        }
    }


}
