﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    interface IBankAccount
    {
        void Deposit(double amount);
        void Withdraw(double amount);
    }


    class SavingAccount : IBankAccount
    {
        int accountNo;
        double balance;

        public SavingAccount(int accno)
        {
            this.accountNo = accno;
        }
        public void Deposit(double amount)
        {
            Console.WriteLine($"depositing Rupees {amount} in savings account");
            this.balance += amount;
            Console.WriteLine($"Account No: {this.accountNo}\nnew balance is {this.balance}");
        }

        public void Withdraw(double amount)
        {
            Console.WriteLine($"withdrawing from saving account Rupees {amount}");
            if (this.balance < amount)
            {
                throw new NoBalanceException();
            }
            else
            {
                this.balance -= amount;
                Console.WriteLine($"Account No: {this.accountNo}\nnew balance is {this.balance}");
            }
        }
    }


    class CurrentAccount : IBankAccount
    {
        int accountNo;
        double balance;

        public CurrentAccount(int accno)
        {
            this.accountNo = accno;
        }

        public void Deposit(double amount)
        {
            Console.WriteLine($"depositing Rupees {amount} in current account");
            this.balance += amount;
            Console.WriteLine($"Account No: {this.accountNo}\nnew balance is {this.balance}");
        }

        public void Withdraw(double amount)
        {
            Console.WriteLine($"withdrawing from current account Rupees {amount}");
            if (this.balance < amount)
            {
                throw new NoBalanceException();
            }
            else
            {
                this.balance -= amount;
                Console.WriteLine($"Account No: {this.accountNo}\nnew balance is {this.balance}");
            }
            
        }
    }


    class BankDemo
    {
        static void Main()
        {

            SavingAccount account1 = new SavingAccount(123);
            CurrentAccount account2 = new CurrentAccount(456);
            try
            {
                //saving account operations
                account1.Deposit(1000);
                account1.Deposit(1000);
                account1.Withdraw(500);

                //current account operations
                //account2.Withdraw(10000);
                account2.Deposit(5000);
                account2.Withdraw(2000);
            }
            catch (NoBalanceException ex)
            {

                Console.WriteLine(ex.Message);
            }

            Console.ReadLine();
        }
    }
}
