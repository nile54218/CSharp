﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class SItotal
    {
        static void Main()
        {
            SItotal obj = new SItotal();
            Console.WriteLine("Enter principle amount");
            double principle = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter rate of interest");
            double rate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter duration");
            double time = Convert.ToDouble(Console.ReadLine());

            double total;
            obj.CalculateSI(principle, rate, time,out total);
            Console.WriteLine($"total payable amount {total}");
            Console.ReadLine();

        }

        public void CalculateSI(double p, double r, double t,out double total)
        {
            double SI = (p * r * t) / 100;
            Console.WriteLine($"Simple Interest {SI}");
            total = p + SI;
        }
    }
}
