﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class SIamount
    {
        static void Main()
        {
            SIamount obj = new SIamount();
            Console.WriteLine("Enter principle amount");
            double principle = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter rate of interest");
            double rate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter duration");
            double time = Convert.ToDouble(Console.ReadLine());

            obj.CalculateSI(principle,rate,time);
            Console.ReadLine();

        }

        public void CalculateSI(double p,double r,double t)
        {
            double SI = (p * r * t) / 100;
            Console.WriteLine($"Simple Interest {SI}");
        }

    }
}
