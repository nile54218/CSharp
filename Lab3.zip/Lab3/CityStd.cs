﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class CityStd
    {

        static void Main()
        {
            Console.WriteLine("all City names");
            foreach (var city in Enum.GetNames(typeof(Cities)))
            {
                Console.WriteLine($"{city}");
            }

            Console.WriteLine("all City STD codes");
            foreach (int code in Enum.GetValues(typeof(Cities)))
            {
                Console.WriteLine($"{code}");
            }

            Console.ReadLine();
        }
        public enum Cities
        {
            pune=100,mumbai=200,satara=300,nagpur=400
        }
    }
}
