﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class Factorial
    {
        static void Main(string[] args)
        {
            Factorial obj = new Factorial();
            Console.WriteLine("Enter a number to get factorial");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("factorial = {0}", obj.factorial(num));
            Console.ReadLine();
        }
        public int factorial(int num)
        {
            int fact=1;
            for (int i = 2; i <= num; i++)
            {
                fact = fact * i;
            }
            return fact;
        }

    }
}
