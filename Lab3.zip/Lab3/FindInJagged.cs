﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class FindInJagged
    {
       static void Main()
        {
            int[][] arr = new int[2][];
            arr[0] = new int[2] { 10, 20 };
            arr[1] = new int[3] { 30, 40, 50 };

            Console.WriteLine("enter target element");
            int target = Convert.ToInt32(Console.ReadLine());

            FindInJagged obj = new FindInJagged();
            obj.FindTarget(target,arr);
            Console.ReadLine();

        }


        public void FindTarget(int target,int[][] arr)
        {
            int flag = 0;
            for (int i = 0; i < 2; i++)
            {
                foreach (var item in arr[i])
                {
                    if (item==target)
                    {
                        Console.WriteLine("target found!");
                        flag = 1;
                        break;
                    }
                }
                if (flag==1)
                {
                    break;
                }
            }

            if (flag==0)
            {
                Console.WriteLine("target not found....try another number!");
            }
        }

        
    }
}
