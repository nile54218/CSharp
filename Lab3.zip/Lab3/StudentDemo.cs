﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class StudentDemo
    {
        static void Main()
        {
            Student s = new Student(1,"nilesh","male",89423894);
            Console.WriteLine(s.Display());
            Console.ReadLine();
        }
    }

    struct Student
    {
        int RollNo;
        string Name;
        string Gender;
        int MobileNo;
        public Student(int RollNo, string Name, string Gender,int MobileNo)
        {
            this.RollNo = RollNo;
            this.Name = Name;
            this.Gender = Gender;
            this.MobileNo = MobileNo;
        }

        public string Display()
        {
            return string.Format("Student RollNo={0} Name={1} Gender={2} MobileNo={3}", RollNo, Name, Gender,MobileNo);
        }

    }
}
