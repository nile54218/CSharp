﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class GstAmount
    {
        static void Main()
        {
            GstAmount obj = new GstAmount();
            
            Console.WriteLine("Enter bill amount");
            double bill = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter rate of GST");
            double rate = Convert.ToDouble(Console.ReadLine());

            double gst_amt;
            obj.Calculate(bill, out gst_amt, rate);
            Console.WriteLine($"total GST amount {gst_amt}");
            Console.ReadLine();

        }

        public void Calculate(double bill, out double gstamt, double gst=1)
        {

           
            gstamt = gst / 100 * bill;
            
        }
    }
}
